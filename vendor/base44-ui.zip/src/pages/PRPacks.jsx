import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { GitBranch, Package, CheckCircle2, ArrowRight, Sparkles } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import PRPackCard from "../components/prpacks/PRPackCard";

const prPacks = [
  {
    id: "merge_queue",
    name: "Add Merge Queue CI",
    description: "Sets up GitHub merge queue with smoke tests. Prevents bad merges and ensures CI runs on queue entries.",
    agent: "ci_cd",
    checks: ["Merge Queue CI / smoke"],
    difficulty: "easy",
    time: "2 min"
  },
  {
    id: "baseline_guard",
    name: "Add Baseline Guard",
    description: "Creates a baseline verification workflow that runs on every PR. Catches regressions early.",
    agent: "ci_cd",
    checks: ["Baseline Guard / verify"],
    difficulty: "easy",
    time: "2 min"
  },
  {
    id: "pr_size_gate",
    name: "Add PR Size Gate",
    description: "Enforces PR size limits to keep changes reviewable. Fails PRs with too many changes.",
    agent: "ci_cd",
    checks: ["PR Size Gate / gate"],
    difficulty: "easy",
    time: "1 min"
  },
  {
    id: "normalize_workflows",
    name: "Normalize Workflow Names",
    description: "Adds run-name and concurrency controls to all workflows. Makes Actions UI readable and dedupes runs.",
    agent: "ci_cd",
    checks: [],
    difficulty: "medium",
    time: "3 min"
  },
  {
    id: "branch_protection",
    name: "Setup Branch Protection",
    description: "Configures branch protection rules with required checks, approvals, and linear history enforcement.",
    agent: "security",
    checks: ["Branch Protection / configured"],
    difficulty: "medium",
    time: "5 min"
  },
  {
    id: "auto_merge",
    name: "Enable Auto-Merge",
    description: "Sets up auto-merge on label with branch deletion. PRs labeled 'auto-merge' merge automatically when green.",
    agent: "code_review",
    checks: ["Auto-merge / enabled"],
    difficulty: "easy",
    time: "2 min"
  },
  {
    id: "nightly_demo",
    name: "Add Nightly Demo",
    description: "Creates nightly artifact with repo name, run ID, and timestamp. Great for demos and verification.",
    agent: "ci_cd",
    checks: ["Nightly Demo / artifact"],
    difficulty: "easy",
    time: "2 min"
  },
  {
    id: "vendor_copilotkit",
    name: "Add CopilotKit Vendor",
    description: "Adds CopilotKit as a submodule under vendor/. One-shot vendor integration.",
    agent: "vendor",
    checks: [],
    difficulty: "easy",
    time: "1 min"
  },
  {
    id: "full_setup",
    name: "🚀 Full Ops Setup",
    description: "Runs all PR packs in sequence. Takes your repo from zero to ops-ready in under 15 minutes.",
    agent: "atlas",
    checks: ["All checks"],
    difficulty: "comprehensive",
    time: "15 min"
  }
];

export default function PRPacksPage() {
  const [selectedRepo, setSelectedRepo] = useState("");
  const [selectedAgent, setSelectedAgent] = useState("all");

  const { data: repos } = useQuery({
    queryKey: ['repos'],
    queryFn: () => base44.entities.GitHubRepo.list(),
    initialData: [],
  });

  const filteredPacks = selectedAgent === "all" 
    ? prPacks 
    : prPacks.filter(pack => pack.agent === selectedAgent);

  return (
    <div className="max-w-7xl mx-auto px-6 py-12">
      {/* Hero */}
      <div className="mb-12">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-blue-500/10 border border-blue-500/30 mb-4">
          <Package className="w-4 h-4 text-blue-400" />
          <span className="text-sm text-blue-400 font-medium">Idempotent Operations</span>
        </div>
        <h1 className="text-5xl font-bold text-white mb-4 bg-gradient-to-r from-white via-slate-200 to-slate-400 bg-clip-text text-transparent">
          PR Packs Library
        </h1>
        <p className="text-xl text-slate-400 max-w-2xl">
          One-click operations that open focused PRs. Safe, idempotent, and designed for non-experts.
        </p>
      </div>

      {/* Filters */}
      <div className="mb-8 flex flex-col sm:flex-row gap-4">
        <div className="flex-1">
          <Select value={selectedRepo} onValueChange={setSelectedRepo}>
            <SelectTrigger className="bg-slate-900/50 border-slate-800 text-white">
              <SelectValue placeholder="Select a repository" />
            </SelectTrigger>
            <SelectContent className="bg-slate-900 border-slate-800">
              <SelectItem value={null}>All Repositories</SelectItem>
              {repos.map((repo) => (
                <SelectItem key={repo.id} value={repo.id}>
                  {repo.repo_name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="flex-1">
          <Select value={selectedAgent} onValueChange={setSelectedAgent}>
            <SelectTrigger className="bg-slate-900/50 border-slate-800 text-white">
              <SelectValue placeholder="Filter by agent" />
            </SelectTrigger>
            <SelectContent className="bg-slate-900 border-slate-800">
              <SelectItem value="all">All Agents</SelectItem>
              <SelectItem value="atlas">🗺️ Atlas</SelectItem>
              <SelectItem value="ci_cd">⚙️ CI/CD Agent</SelectItem>
              <SelectItem value="security">🔒 Security Agent</SelectItem>
              <SelectItem value="code_review">📝 Code Review Agent</SelectItem>
              <SelectItem value="vendor">📦 Vendor Agent</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {repos.length === 0 ? (
        <Card className="bg-slate-900/50 border-slate-800 p-12 text-center">
          <GitBranch className="w-16 h-16 text-slate-600 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-white mb-2">No repositories yet</h3>
          <p className="text-slate-400 mb-6">Add a repository first to use PR Packs</p>
          <Button className="bg-gradient-to-r from-blue-500 to-emerald-500">
            Add Your First Repo
          </Button>
        </Card>
      ) : !selectedRepo ? (
        <Card className="bg-slate-900/50 border-slate-800 p-12 text-center">
          <Package className="w-16 h-16 text-blue-500 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-white mb-2">Select a Repository</h3>
          <p className="text-slate-400">Choose a repository above to see available PR Packs</p>
        </Card>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredPacks.map((pack) => (
            <PRPackCard key={pack.id} pack={pack} repoId={selectedRepo} />
          ))}
        </div>
      )}
    </div>
  );
}