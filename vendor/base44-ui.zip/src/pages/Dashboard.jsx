
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Sparkles, Plus, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import RepoStatusCard from "../components/dashboard/RepoStatusCard";
import AgentCard from "../components/dashboard/AgentCard";
import AddRepoDialog from "../components/dashboard/AddRepoDialog";

const agents = [
  {
    type: "atlas",
    name: "Atlas",
    role: "Orchestration & Policy",
    description: "Policy enforcement, settings as code, and workflow orchestration. Ensures your repo stays ops-ready.",
    icon: "🗺️",
    gradient: "from-blue-500 to-cyan-500"
  },
  {
    type: "ci_cd",
    name: "CI/CD Agent",
    role: "Workflow & Guardrails",
    description: "Sets up merge queue CI, baseline guards, PR size gates, and normalizes workflow runs.",
    icon: "⚙️",
    gradient: "from-emerald-500 to-teal-500"
  },
  {
    type: "security",
    name: "Security Agent",
    role: "Branch Protection",
    description: "Configures branch protection, required checks, and enforces approval policies.",
    icon: "🔒",
    gradient: "from-orange-500 to-amber-500"
  },
  {
    type: "code_review",
    name: "Code Review Agent",
    role: "PR Analysis",
    description: "Analyzes PRs for safety, suggests auto-merge eligibility, and manages merge labels.",
    icon: "📝",
    gradient: "from-purple-500 to-pink-500"
  },
  {
    type: "vendor",
    name: "Vendor Agent",
    role: "Dependencies",
    description: "Manages vendor submodules, adds curated libraries, and handles dependency updates.",
    icon: "📦",
    gradient: "from-indigo-500 to-violet-500"
  }
];

export default function Dashboard() {
  const [showAddRepo, setShowAddRepo] = useState(false);

  const { data: repos, isLoading: loadingRepos } = useQuery({
    queryKey: ['repos'],
    queryFn: () => base44.entities.GitHubRepo.list("-last_scan"),
    initialData: [],
  });

  const { data: operations, isLoading: loadingOps } = useQuery({
    queryKey: ['operations'],
    queryFn: () => base44.entities.Operation.list("-created_date", 10),
    initialData: [],
  });

  return (
    <div className="max-w-7xl mx-auto px-6 py-12">
      {/* Hero Section */}
      <div className="mb-12">
        <div className="flex items-center justify-between mb-6">
          <div>
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-blue-500/10 border border-blue-500/30 mb-4">
              <Sparkles className="w-4 h-4 text-blue-400" />
              <span className="text-sm text-blue-400 font-medium">Chat-First GitHub Operations</span>
            </div>
            <h1 className="text-5xl font-bold text-white mb-4 bg-gradient-to-r from-white via-slate-200 to-slate-400 bg-clip-text text-transparent">
              Make Repos Ops-Ready
            </h1>
            <p className="text-xl text-slate-400 max-w-2xl">
              Multi-agent co-pilot for CI guardrails, branch protection, auto-merge—no terminal required
            </p>
          </div>
          <Button 
            onClick={() => setShowAddRepo(true)}
            className="bg-gradient-to-r from-blue-500 to-emerald-500 hover:from-blue-600 hover:to-emerald-600 text-white shadow-lg shadow-blue-500/30"
          >
            <Plus className="w-5 h-5 mr-2" />
            Add Repository
          </Button>
        </div>
      </div>

      {/* Repositories Status */}
      {repos.length > 0 && (
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-white mb-6">Your Repositories</h2>
          <div className="grid gap-6">
            {repos.map((repo) => (
              <RepoStatusCard key={repo.id} repo={repo} operations={operations.filter(op => op.repo_id === repo.id)} />
            ))}
          </div>
        </div>
      )}

      {repos.length === 0 && !loadingRepos && (
        <div className="mb-12 text-center py-12 border-2 border-dashed border-slate-800 rounded-2xl">
          <Shield className="w-16 h-16 text-slate-600 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-white mb-2">No repositories yet</h3>
          <p className="text-slate-400 mb-6">Add your first GitHub repository to get started</p>
          <Button 
            onClick={() => setShowAddRepo(true)}
            className="bg-gradient-to-r from-blue-500 to-emerald-500"
          >
            <Plus className="w-5 h-5 mr-2" />
            Add Your First Repo
          </Button>
        </div>
      )}

      {/* AI Agents */}
      <div className="mb-12">
        <h2 className="text-2xl font-bold text-white mb-6">Your AI Ops Team</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {agents.map((agent) => (
            <AgentCard key={agent.type} {...agent} />
          ))}
        </div>
      </div>

      {/* Add Repo Dialog */}
      <AddRepoDialog open={showAddRepo} onOpenChange={setShowAddRepo} />
    </div>
  );
}
