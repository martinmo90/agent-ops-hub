import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, RefreshCw, Shield, AlertCircle } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import OperationCard from "../components/repo/OperationCard";
import RequiredChecksPanel from "../components/repo/RequiredChecksPanel";
import BranchProtectionDialog from "../components/repo/BranchProtectionDialog";
import TokenValidator from "../components/repo/TokenValidator";

const operations = [
  {
    id: "seed_checks",
    title: "Seed Checks",
    description: "Dispatches key workflows: merge queue CI, baseline guard, PR size gate, benchmark check",
    icon: "🌱",
    gradient: "from-green-500 to-emerald-500"
  },
  {
    id: "baseline_seed_pr",
    title: "Baseline Guard Seed PR",
    description: "Creates a tiny PR to verify PR-only checks work correctly",
    icon: "🧪",
    gradient: "from-blue-500 to-cyan-500"
  },
  {
    id: "nightly_demo",
    title: "Nightly Demo",
    description: "Dispatches nightly workflow and verifies artifact contains repo info",
    icon: "🌙",
    gradient: "from-purple-500 to-indigo-500"
  },
  {
    id: "status_scan",
    title: "Operational Status Scan",
    description: "Summarizes green/red status across all workflows and settings",
    icon: "📊",
    gradient: "from-orange-500 to-amber-500"
  },
  {
    id: "settings_guard",
    title: "Repo Settings Guard",
    description: "Enforces branch protection as code - requires admin token",
    icon: "🔒",
    gradient: "from-red-500 to-pink-500"
  },
  {
    id: "automerge_test",
    title: "Auto-merge Happy-Path",
    description: "Opens test PR with auto-merge label, verifies merge and branch deletion",
    icon: "🔄",
    gradient: "from-teal-500 to-cyan-500"
  }
];

export default function RepoDetailPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const urlParams = new URLSearchParams(window.location.search);
  const repoId = urlParams.get("id");

  const [showBranchProtection, setShowBranchProtection] = useState(false);
  const [githubToken, setGithubToken] = useState("");
  const [tokenValid, setTokenValid] = useState(false);

  const { data: repo, isLoading } = useQuery({
    queryKey: ['repo', repoId],
    queryFn: async () => {
      const repos = await base44.entities.GitHubRepo.filter({ id: repoId });
      return repos[0];
    },
    enabled: !!repoId,
  });

  const { data: repoOperations } = useQuery({
    queryKey: ['operations', repoId],
    queryFn: () => base44.entities.Operation.filter({ repo_id: repoId }, "-created_date"),
    initialData: [],
    enabled: !!repoId,
  });

  const rescanMutation = useMutation({
    mutationFn: async () => {
      // Simulate status scan
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      await base44.entities.GitHubRepo.update(repoId, {
        last_scan: new Date().toISOString(),
        status: "ready"
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['repo', repoId] });
    }
  });

  if (isLoading || !repo) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <Shield className="w-12 h-12 text-blue-500 animate-pulse mx-auto mb-3" />
          <p className="text-slate-400">Loading repository...</p>
        </div>
      </div>
    );
  }

  const completedChecks = Object.values(repo.checks || {}).filter(Boolean).length;
  const totalChecks = 6;
  const readinessPercent = Math.round((completedChecks / totalChecks) * 100);

  return (
    <div className="min-h-screen pb-12">
      {/* Header */}
      <div className="border-b border-slate-800 bg-slate-900/80 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => navigate(createPageUrl("Dashboard"))}
                className="text-slate-400 hover:text-white"
              >
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold text-white">{repo.repo_name}</h1>
                <p className="text-sm text-slate-400 mt-1">Repository Operations Center</p>
              </div>
            </div>
            <Button
              onClick={() => rescanMutation.mutate()}
              disabled={rescanMutation.isPending}
              variant="outline"
              className="border-slate-700 text-slate-300"
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${rescanMutation.isPending ? 'animate-spin' : ''}`} />
              Rescan
            </Button>
          </div>

          {/* Readiness Score */}
          <div className="flex items-center gap-6 bg-slate-800/50 rounded-xl p-4">
            <div className="relative w-20 h-20">
              <svg className="w-20 h-20 transform -rotate-90">
                <circle
                  cx="40"
                  cy="40"
                  r="32"
                  stroke="currentColor"
                  strokeWidth="6"
                  fill="transparent"
                  className="text-slate-700"
                />
                <circle
                  cx="40"
                  cy="40"
                  r="32"
                  stroke="currentColor"
                  strokeWidth="6"
                  fill="transparent"
                  strokeDasharray={`${readinessPercent * 2.01} 201`}
                  className={readinessPercent === 100 ? "text-green-500" : "text-blue-500"}
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-xl font-bold text-white">{readinessPercent}%</span>
              </div>
            </div>
            <div className="flex-1">
              <h3 className="text-lg font-semibold text-white mb-1">Ops Readiness Score</h3>
              <p className="text-sm text-slate-400">
                {completedChecks} of {totalChecks} checks passing
              </p>
              <Badge className="mt-2 bg-blue-500/20 text-blue-400 border-blue-500/30">
                {repo.policy_preset} policy
              </Badge>
            </div>
            <Button
              onClick={() => setShowBranchProtection(true)}
              className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600"
            >
              <Shield className="w-4 h-4 mr-2" />
              Branch Protection
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Token Validator */}
        {!tokenValid && (
          <div className="mb-8">
            <div className="bg-orange-500/10 border border-orange-500/30 rounded-xl p-4 mb-4">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-orange-400 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-orange-400 font-semibold mb-1">GitHub Token Required</h4>
                  <p className="text-sm text-slate-400">
                    To run operations, provide a fine-grained personal access token with appropriate permissions.
                  </p>
                </div>
              </div>
            </div>
            <TokenValidator 
              repo={repo}
              onTokenValid={(token) => {
                setGithubToken(token);
                setTokenValid(true);
              }}
            />
          </div>
        )}

        {/* Operation Cards */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-white mb-6">Operations Dashboard</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {operations.map((op) => (
              <OperationCard 
                key={op.id} 
                operation={op}
                repo={repo}
                recentRuns={repoOperations.filter(o => o.operation_type === op.id)}
                githubToken={githubToken}
                tokenValid={tokenValid}
              />
            ))}
          </div>
        </div>

        {/* Required Checks Panel */}
        <RequiredChecksPanel repo={repo} githubToken={githubToken} />
      </div>

      {/* Branch Protection Dialog */}
      <BranchProtectionDialog 
        open={showBranchProtection}
        onOpenChange={setShowBranchProtection}
        repo={repo}
        githubToken={githubToken}
      />
    </div>
  );
}