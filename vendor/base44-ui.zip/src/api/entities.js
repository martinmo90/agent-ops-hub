import { base44 } from './base44Client';


export const Conversation = base44.entities.Conversation;

export const GitHubRepo = base44.entities.GitHubRepo;

export const Operation = base44.entities.Operation;



// auth sdk:
export const User = base44.auth;