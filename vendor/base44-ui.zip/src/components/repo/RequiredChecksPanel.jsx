import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CheckCircle2, XCircle, Copy, RefreshCw } from "lucide-react";
import { toast } from "sonner";

const requiredChecks = [
  { name: "Merge Queue CI / smoke", key: "merge_queue_ci" },
  { name: "Baseline Guard / verify", key: "baseline_guard" },
  { name: "PR Size Gate / gate", key: "pr_size_gate" },
  { name: "Benchmark Zip Exact Check / check", key: "benchmark_check" }
];

export default function RequiredChecksPanel({ repo, githubToken }) {
  const [discovering, setDiscovering] = useState(false);

  const handleDiscoverChecks = async () => {
    setDiscovering(true);
    await new Promise(resolve => setTimeout(resolve, 2000));
    setDiscovering(false);
    toast.success("Check discovery complete");
  };

  const copyCheckNames = () => {
    const checkNames = requiredChecks.map(c => c.name).join('\n');
    navigator.clipboard.writeText(checkNames);
    toast.success("Check names copied to clipboard");
  };

  return (
    <Card className="bg-slate-900/50 border-slate-800">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-white">Required Checks</CardTitle>
          <div className="flex gap-2">
            <Button
              onClick={copyCheckNames}
              variant="outline"
              size="sm"
              className="border-slate-700 text-slate-300"
            >
              <Copy className="w-4 h-4 mr-2" />
              Copy Names
            </Button>
            <Button
              onClick={handleDiscoverChecks}
              disabled={discovering || !githubToken}
              variant="outline"
              size="sm"
              className="border-slate-700 text-slate-300"
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${discovering ? 'animate-spin' : ''}`} />
              Discover
            </Button>
          </div>
        </div>
        <p className="text-sm text-slate-400 mt-2">
          These checks must pass for branch protection. Copy these exact context strings for GitHub settings.
        </p>
      </CardHeader>
      <CardContent>
        <div className="grid gap-3">
          {requiredChecks.map((check) => {
            const isPassing = repo.checks?.[check.key];
            
            return (
              <div
                key={check.key}
                className={`flex items-center justify-between p-4 rounded-lg border ${
                  isPassing
                    ? 'bg-green-500/10 border-green-500/30'
                    : 'bg-slate-800/50 border-slate-700'
                }`}
              >
                <div className="flex items-center gap-3">
                  {isPassing ? (
                    <CheckCircle2 className="w-5 h-5 text-green-400" />
                  ) : (
                    <XCircle className="w-5 h-5 text-slate-600" />
                  )}
                  <div>
                    <p className={`font-medium ${isPassing ? 'text-green-300' : 'text-slate-300'}`}>
                      {check.name}
                    </p>
                    <p className="text-xs text-slate-500 mt-0.5 font-mono">
                      context: "{check.name}"
                    </p>
                  </div>
                </div>
                <Badge
                  variant="outline"
                  className={isPassing ? 'border-green-500/30 text-green-400' : 'border-slate-700 text-slate-500'}
                >
                  {isPassing ? 'Active' : 'Not Found'}
                </Badge>
              </div>
            );
          })}
        </div>

        <div className="mt-6 p-4 bg-blue-500/10 border border-blue-500/30 rounded-lg">
          <h4 className="text-sm font-semibold text-blue-400 mb-2">💡 Setup Tip</h4>
          <p className="text-xs text-slate-400">
            Run "Seed Checks" operation first to emit these contexts. Then use "Branch Protection" 
            to configure them as required checks. The exact context strings are shown above.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}