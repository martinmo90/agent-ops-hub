import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Shield, Lock, Loader2, CheckCircle2, AlertTriangle } from "lucide-react";
import { toast } from "sonner";

export default function BranchProtectionDialog({ open, onOpenChange, repo, githubToken }) {
  const [adminToken, setAdminToken] = useState("");
  const [useAdminToken, setUseAdminToken] = useState(false);
  const [result, setResult] = useState(null);

  const [settings, setSettings] = useState({
    requirePR: true,
    requiredApprovals: 1,
    dismissStaleReviews: true,
    strictUpToDate: true,
    conversationResolution: true,
    linearHistory: true,
    allowAutoMerge: true
  });

  const applyProtectionMutation = useMutation({
    mutationFn: async () => {
      const tokenToUse = useAdminToken ? adminToken : githubToken;
      
      if (!tokenToUse) {
        throw new Error("GitHub token required");
      }

      // Simulate applying branch protection
      await new Promise(resolve => setTimeout(resolve, 2500));

      // Simulate checking if we have admin rights
      const hasAdminRights = useAdminToken || Math.random() > 0.5;

      if (!hasAdminRights) {
        return {
          success: false,
          needsAdmin: true,
          message: "Current token lacks admin permissions. Please provide an admin token."
        };
      }

      // Success - simulate protection applied
      const protection = {
        required_pull_request_reviews: {
          required_approving_review_count: settings.requiredApprovals,
          dismiss_stale_reviews: settings.dismissStaleReviews
        },
        required_status_checks: {
          strict: settings.strictUpToDate,
          checks: [
            { context: "Merge Queue CI / smoke" },
            { context: "Baseline Guard / verify" },
            { context: "PR Size Gate / gate" },
            { context: "Benchmark Zip Exact Check / check" }
          ]
        },
        required_conversation_resolution: settings.conversationResolution,
        required_linear_history: settings.linearHistory,
        allow_auto_merge: settings.allowAutoMerge
      };

      return {
        success: true,
        needsAdmin: false,
        protection,
        message: "Branch protection successfully applied!"
      };
    },
    onSuccess: (result) => {
      setResult(result);
      if (result.success) {
        toast.success("Branch protection configured!");
      } else if (result.needsAdmin) {
        toast.error(result.message);
      }
    },
    onError: () => {
      toast.error("Failed to apply branch protection");
    }
  });

  const handleApply = () => {
    setResult(null);
    applyProtectionMutation.mutate();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-slate-900 border-slate-800 text-white max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <Shield className="w-6 h-6 text-orange-400" />
            Branch Protection Settings
          </DialogTitle>
          <DialogDescription className="text-slate-400">
            Configure branch protection for <span className="font-mono text-blue-400">main</span> branch
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 mt-4">
          {/* Settings */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <Checkbox
                id="requirePR"
                checked={settings.requirePR}
                onCheckedChange={(checked) => setSettings({ ...settings, requirePR: checked })}
              />
              <Label htmlFor="requirePR" className="text-slate-300 cursor-pointer">
                Require pull request before merging
              </Label>
            </div>

            {settings.requirePR && (
              <div className="ml-8 space-y-3">
                <div className="flex items-center gap-3">
                  <Label className="text-slate-400 w-48">Required approvals:</Label>
                  <Input
                    type="number"
                    min="1"
                    max="6"
                    value={settings.requiredApprovals}
                    onChange={(e) => setSettings({ ...settings, requiredApprovals: parseInt(e.target.value) })}
                    className="w-20 bg-slate-800 border-slate-700 text-white"
                  />
                </div>

                <div className="flex items-center gap-3">
                  <Checkbox
                    id="dismissStale"
                    checked={settings.dismissStaleReviews}
                    onCheckedChange={(checked) => setSettings({ ...settings, dismissStaleReviews: checked })}
                  />
                  <Label htmlFor="dismissStale" className="text-slate-300 cursor-pointer">
                    Dismiss stale reviews on new commits
                  </Label>
                </div>
              </div>
            )}

            <div className="flex items-center gap-3">
              <Checkbox
                id="strictUpToDate"
                checked={settings.strictUpToDate}
                onCheckedChange={(checked) => setSettings({ ...settings, strictUpToDate: checked })}
              />
              <Label htmlFor="strictUpToDate" className="text-slate-300 cursor-pointer">
                Require branches to be up to date before merging
              </Label>
            </div>

            <div className="flex items-center gap-3">
              <Checkbox
                id="conversationResolution"
                checked={settings.conversationResolution}
                onCheckedChange={(checked) => setSettings({ ...settings, conversationResolution: checked })}
              />
              <Label htmlFor="conversationResolution" className="text-slate-300 cursor-pointer">
                Require conversation resolution before merging
              </Label>
            </div>

            <div className="flex items-center gap-3">
              <Checkbox
                id="linearHistory"
                checked={settings.linearHistory}
                onCheckedChange={(checked) => setSettings({ ...settings, linearHistory: checked })}
              />
              <Label htmlFor="linearHistory" className="text-slate-300 cursor-pointer">
                Require linear history (no merge commits)
              </Label>
            </div>

            <div className="flex items-center gap-3">
              <Checkbox
                id="allowAutoMerge"
                checked={settings.allowAutoMerge}
                onCheckedChange={(checked) => setSettings({ ...settings, allowAutoMerge: checked })}
              />
              <Label htmlFor="allowAutoMerge" className="text-slate-300 cursor-pointer">
                Allow auto-merge
              </Label>
            </div>
          </div>

          {/* Admin Token Section */}
          {result?.needsAdmin && (
            <div className="bg-orange-500/10 border border-orange-500/30 rounded-lg p-4">
              <div className="flex items-start gap-3 mb-3">
                <AlertTriangle className="w-5 h-5 text-orange-400 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-orange-400 font-semibold mb-1">Admin Token Required</h4>
                  <p className="text-sm text-slate-400">
                    Modifying branch protection requires repository admin permissions. 
                    Provide a short-lived admin token (it won't be stored).
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 mt-3">
                <Checkbox
                  id="useAdminToken"
                  checked={useAdminToken}
                  onCheckedChange={setUseAdminToken}
                />
                <Label htmlFor="useAdminToken" className="text-slate-300 cursor-pointer text-sm">
                  Use admin token
                </Label>
              </div>

              {useAdminToken && (
                <Input
                  type="password"
                  placeholder="github_pat_... (admin scope)"
                  value={adminToken}
                  onChange={(e) => setAdminToken(e.target.value)}
                  className="mt-3 bg-slate-800 border-slate-700 text-white"
                />
              )}
            </div>
          )}

          {/* Success Result */}
          {result?.success && (
            <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-4">
              <div className="flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-green-400 font-semibold mb-2">Protection Applied!</h4>
                  <div className="text-xs text-slate-300 space-y-1 font-mono">
                    <p>✓ Required approvals: {result.protection.required_pull_request_reviews.required_approving_review_count}</p>
                    <p>✓ Status checks: {result.protection.required_status_checks.checks.length} required</p>
                    <p>✓ Linear history: enabled</p>
                    <p>✓ Auto-merge: {result.protection.allow_auto_merge ? 'enabled' : 'disabled'}</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Actions */}
          <div className="flex justify-end gap-3 pt-4">
            <Button
              variant="outline"
              onClick={() => onOpenChange(false)}
              className="border-slate-700 text-slate-300"
            >
              Cancel
            </Button>
            <Button
              onClick={handleApply}
              disabled={applyProtectionMutation.isPending || (!githubToken && !useAdminToken)}
              className="bg-gradient-to-r from-orange-500 to-red-500"
            >
              {applyProtectionMutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Applying...
                </>
              ) : (
                <>
                  <Lock className="w-4 h-4 mr-2" />
                  Apply Protection
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}