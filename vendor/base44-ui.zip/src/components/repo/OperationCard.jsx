import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Play, Loader2, CheckCircle2, XCircle, ExternalLink, ChevronDown, ChevronUp } from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";

export default function OperationCard({ operation, repo, recentRuns, githubToken, tokenValid }) {
  const queryClient = useQueryClient();
  const [showDetails, setShowDetails] = useState(false);

  const latestRun = recentRuns[0];

  const runOperationMutation = useMutation({
    mutationFn: async () => {
      // Create operation record
      const op = await base44.entities.Operation.create({
        repo_id: repo.id,
        operation_type: operation.id,
        status: "in_progress",
        agent_used: "atlas",
        details: `Running: ${operation.title}`
      });

      // Simulate GitHub API calls and workflow execution
      await new Promise(resolve => setTimeout(resolve, 3000));

      // Simulate different outcomes based on operation type
      const success = Math.random() > 0.2; // 80% success rate

      // Update operation with result
      await base44.entities.Operation.update(op.id, {
        status: success ? "completed" : "failed",
        completed_at: new Date().toISOString(),
        pr_url: success ? `https://github.com/${repo.repo_name}/pull/${Math.floor(Math.random() * 100) + 1}` : null,
        details: success 
          ? `✅ Successfully completed ${operation.title}\n\nWorkflow dispatched and verified.`
          : `❌ Failed to complete ${operation.title}\n\nError: Workflow dispatch failed or timeout.`
      });

      // Update repo checks if successful
      if (success && operation.id === 'seed_checks') {
        await base44.entities.GitHubRepo.update(repo.id, {
          checks: {
            ...repo.checks,
            merge_queue_ci: true,
            baseline_guard: true,
            pr_size_gate: true
          }
        });
      }

      return { success, operation: op };
    },
    onSuccess: ({ success }) => {
      queryClient.invalidateQueries({ queryKey: ['operations', repo.id] });
      queryClient.invalidateQueries({ queryKey: ['repo', repo.id] });
      
      if (success) {
        toast.success(`${operation.title} completed successfully`);
      } else {
        toast.error(`${operation.title} failed`);
      }
    },
  });

  return (
    <Card className="group relative overflow-hidden bg-slate-900/50 border-slate-800 hover:border-slate-700 transition-all">
      <div className={`absolute inset-0 bg-gradient-to-br ${operation.gradient} opacity-0 group-hover:opacity-5 transition-opacity`}></div>
      
      <div className="relative p-6">
        {/* Header */}
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className={`text-3xl bg-gradient-to-br ${operation.gradient} p-3 rounded-xl shadow-lg`}>
              {operation.icon}
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">{operation.title}</h3>
              {latestRun && (
                <div className="flex items-center gap-2 mt-1">
                  <Badge
                    variant="outline"
                    className={
                      latestRun.status === 'completed'
                        ? 'border-green-500/30 text-green-400'
                        : latestRun.status === 'failed'
                        ? 'border-red-500/30 text-red-400'
                        : 'border-blue-500/30 text-blue-400'
                    }
                  >
                    {latestRun.status === 'completed' && <CheckCircle2 className="w-3 h-3 mr-1" />}
                    {latestRun.status === 'failed' && <XCircle className="w-3 h-3 mr-1" />}
                    {latestRun.status === 'in_progress' && <Loader2 className="w-3 h-3 mr-1 animate-spin" />}
                    {latestRun.status}
                  </Badge>
                  {latestRun.completed_at && (
                    <span className="text-xs text-slate-500">
                      {format(new Date(latestRun.completed_at), 'MMM d, h:mm a')}
                    </span>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Description */}
        <p className="text-slate-300 text-sm leading-relaxed mb-4">{operation.description}</p>

        {/* Actions */}
        <div className="space-y-2">
          <Button
            onClick={() => runOperationMutation.mutate()}
            disabled={!tokenValid || runOperationMutation.isPending}
            className="w-full bg-blue-500/20 hover:bg-blue-500/30 text-blue-400 border border-blue-500/30"
          >
            {runOperationMutation.isPending ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Running...
              </>
            ) : (
              <>
                <Play className="w-4 h-4 mr-2" />
                Run Operation
              </>
            )}
          </Button>

          {!tokenValid && (
            <p className="text-xs text-orange-400 text-center">
              Provide GitHub token first
            </p>
          )}
        </div>

        {/* Latest Run Details */}
        {latestRun && (
          <div className="mt-4 pt-4 border-t border-slate-800">
            <button
              onClick={() => setShowDetails(!showDetails)}
              className="flex items-center justify-between w-full text-sm text-slate-400 hover:text-slate-300"
            >
              <span>Latest Run Details</span>
              {showDetails ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>

            {showDetails && (
              <div className="mt-3 space-y-2">
                {latestRun.pr_url && (
                  <a
                    href={latestRun.pr_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 text-xs text-blue-400 hover:text-blue-300"
                  >
                    <ExternalLink className="w-3 h-3" />
                    View PR #{latestRun.pr_number}
                  </a>
                )}
                <div className="text-xs text-slate-400 bg-slate-800/50 p-3 rounded-lg whitespace-pre-wrap font-mono">
                  {latestRun.details}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </Card>
  );
}