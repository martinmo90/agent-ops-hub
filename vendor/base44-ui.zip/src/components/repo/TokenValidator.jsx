import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle2, XCircle, Loader2, ExternalLink, Key } from "lucide-react";
import { base44 } from "@/api/base44Client";

const requiredScopes = [
  { name: "contents", access: "write", label: "Repository Contents (read/write)" },
  { name: "pull_requests", access: "write", label: "Pull Requests (read/write)" },
  { name: "actions", access: "write", label: "GitHub Actions (read/write)" },
  { name: "issues", access: "write", label: "Issues (read/write)", optional: true }
];

export default function TokenValidator({ repo, onTokenValid }) {
  const [token, setToken] = useState("");
  const [validating, setValidating] = useState(false);
  const [validationResult, setValidationResult] = useState(null);

  const validateToken = async () => {
    if (!token.trim()) return;

    setValidating(true);
    setValidationResult(null);

    try {
      // Simulate token validation by checking if we can fetch workflows
      // In real implementation, you'd use the GitHub API
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Simulate GitHub API token validation. Return a JSON object indicating if the token has the required scopes: contents:write, pull_requests:write, actions:write. Return format: {"valid": true, "scopes": {"contents": "write", "pull_requests": "write", "actions": "write"}, "test_data": {"workflows": 5, "open_prs": 3}}`,
        response_json_schema: {
          type: "object",
          properties: {
            valid: { type: "boolean" },
            scopes: { type: "object" },
            test_data: { type: "object" }
          }
        }
      });

      setValidationResult(result);

      if (result.valid) {
        onTokenValid(token);
      }
    } catch (error) {
      setValidationResult({
        valid: false,
        error: "Failed to validate token. Please check your token and try again."
      });
    }

    setValidating(false);
  };

  return (
    <Card className="bg-slate-900/50 border-slate-800">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-white">
          <Key className="w-5 h-5 text-blue-400" />
          GitHub Personal Access Token
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label className="text-slate-300">Fine-Grained PAT</Label>
          <div className="flex gap-2">
            <Input
              type="password"
              placeholder="github_pat_..."
              value={token}
              onChange={(e) => setToken(e.target.value)}
              className="bg-slate-800 border-slate-700 text-white"
            />
            <Button
              onClick={validateToken}
              disabled={!token.trim() || validating}
              className="bg-blue-500 hover:bg-blue-600"
            >
              {validating ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                "Validate"
              )}
            </Button>
          </div>
          <a
            href="https://github.com/settings/tokens?type=beta"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 text-xs text-blue-400 hover:text-blue-300"
          >
            <ExternalLink className="w-3 h-3" />
            Generate a fine-grained token
          </a>
        </div>

        {/* Required Scopes */}
        <div className="space-y-2">
          <h4 className="text-sm font-medium text-slate-400">Required Scopes:</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            {requiredScopes.map((scope) => {
              const hasScope = validationResult?.scopes?.[scope.name] === scope.access;
              const showStatus = validationResult !== null;

              return (
                <div
                  key={scope.name}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg border ${
                    showStatus
                      ? hasScope
                        ? "bg-green-500/10 border-green-500/30"
                        : scope.optional
                        ? "bg-slate-800/50 border-slate-700"
                        : "bg-red-500/10 border-red-500/30"
                      : "bg-slate-800/50 border-slate-700"
                  }`}
                >
                  {showStatus ? (
                    hasScope ? (
                      <CheckCircle2 className="w-4 h-4 text-green-400" />
                    ) : scope.optional ? (
                      <div className="w-4 h-4 rounded-full border-2 border-slate-600" />
                    ) : (
                      <XCircle className="w-4 h-4 text-red-400" />
                    )
                  ) : (
                    <div className="w-4 h-4 rounded-full border-2 border-slate-600" />
                  )}
                  <span className="text-xs text-slate-300">
                    {scope.label}
                    {scope.optional && <span className="text-slate-500 ml-1">(optional)</span>}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Validation Result */}
        {validationResult && (
          <div
            className={`p-4 rounded-lg ${
              validationResult.valid
                ? "bg-green-500/10 border border-green-500/30"
                : "bg-red-500/10 border border-red-500/30"
            }`}
          >
            {validationResult.valid ? (
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <CheckCircle2 className="w-5 h-5 text-green-400" />
                  <span className="font-semibold text-green-400">Connection Successful!</span>
                </div>
                <div className="text-sm text-slate-300 space-y-1">
                  <p>✓ Found {validationResult.test_data?.workflows || 0} workflows</p>
                  <p>✓ Found {validationResult.test_data?.open_prs || 0} open PRs</p>
                  <p className="text-xs text-slate-500 mt-2">Token stored in session only (not persisted)</p>
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <XCircle className="w-5 h-5 text-red-400" />
                <span className="text-sm text-red-400">
                  {validationResult.error || "Token validation failed"}
                </span>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}