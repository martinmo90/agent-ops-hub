import React from "react";
import ReactMarkdown from "react-markdown";
import { User, Sparkles } from "lucide-react";

const assistantColors = {
  chatgpt: "from-emerald-500 to-teal-500",
  copilot: "from-blue-500 to-cyan-500",
  claude: "from-orange-500 to-amber-500",
  cursor: "from-purple-500 to-pink-500"
};

export default function MessageBubble({ message, assistantType }) {
  const isUser = message.role === "user";

  return (
    <div className={`flex gap-4 ${isUser ? "justify-end" : "justify-start"}`}>
      {!isUser && (
        <div className={`flex-shrink-0 w-10 h-10 rounded-xl bg-gradient-to-br ${assistantColors[assistantType]} flex items-center justify-center shadow-lg`}>
          <Sparkles className="w-5 h-5 text-white" />
        </div>
      )}
      
      <div className={`max-w-[80%] ${isUser ? "order-first" : ""}`}>
        <div className={`rounded-2xl px-5 py-3 ${
          isUser 
            ? "bg-indigo-500 text-white shadow-lg shadow-indigo-500/30" 
            : "bg-slate-800/70 text-slate-100 border border-slate-700"
        }`}>
          {isUser ? (
            <p className="text-sm leading-relaxed whitespace-pre-wrap">{message.content}</p>
          ) : (
            <ReactMarkdown
              className="text-sm prose prose-invert prose-sm max-w-none [&>*:first-child]:mt-0 [&>*:last-child]:mb-0"
              components={{
                code: ({ inline, children, ...props }) => {
                  return inline ? (
                    <code className="px-1.5 py-0.5 rounded bg-slate-900 text-indigo-300 text-xs font-mono" {...props}>
                      {children}
                    </code>
                  ) : (
                    <pre className="bg-slate-900 rounded-lg p-4 overflow-x-auto my-2 border border-slate-700">
                      <code className="text-xs font-mono text-slate-200" {...props}>{children}</code>
                    </pre>
                  );
                },
                p: ({ children }) => <p className="my-2 leading-relaxed">{children}</p>,
                ul: ({ children }) => <ul className="my-2 ml-4 list-disc space-y-1">{children}</ul>,
                ol: ({ children }) => <ol className="my-2 ml-4 list-decimal space-y-1">{children}</ol>,
                li: ({ children }) => <li className="leading-relaxed">{children}</li>,
                h3: ({ children }) => <h3 className="text-base font-semibold my-3 text-white">{children}</h3>,
                a: ({ children, href }) => (
                  <a href={href} target="_blank" rel="noopener noreferrer" className="text-indigo-400 hover:text-indigo-300 underline">
                    {children}
                  </a>
                ),
              }}
            >
              {message.content}
            </ReactMarkdown>
          )}
        </div>
      </div>

      {isUser && (
        <div className="flex-shrink-0 w-10 h-10 rounded-xl bg-gradient-to-br from-slate-700 to-slate-600 flex items-center justify-center shadow-lg">
          <User className="w-5 h-5 text-white" />
        </div>
      )}
    </div>
  );
}