import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { GitBranch, Loader2 } from "lucide-react";

export default function AddRepoDialog({ open, onOpenChange }) {
  const queryClient = useQueryClient();
  const [repoUrl, setRepoUrl] = useState("");
  const [policyPreset, setPolicyPreset] = useState("solo");

  const addRepoMutation = useMutation({
    mutationFn: async () => {
      // Extract repo name from URL
      const match = repoUrl.match(/github\.com\/([^\/]+\/[^\/]+)/);
      if (!match) throw new Error("Invalid GitHub URL");
      
      const repoName = match[1].replace(/\.git$/, "");
      
      return base44.entities.GitHubRepo.create({
        repo_url: repoUrl,
        repo_name: repoName,
        status: "initializing",
        policy_preset: policyPreset,
        checks: {
          merge_queue_ci: false,
          baseline_guard: false,
          pr_size_gate: false,
          branch_protection: false,
          auto_merge: false,
          nightly_demo: false
        },
        last_scan: new Date().toISOString()
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['repos'] });
      setRepoUrl("");
      setPolicyPreset("solo");
      onOpenChange(false);
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    addRepoMutation.mutate();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-slate-900 border-slate-800 text-white">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <GitBranch className="w-5 h-5 text-blue-400" />
            Add GitHub Repository
          </DialogTitle>
          <DialogDescription className="text-slate-400">
            Add a repository to make it ops-ready with our AI agents
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6 mt-4">
          <div className="space-y-2">
            <Label htmlFor="repo-url" className="text-slate-300">Repository URL</Label>
            <Input
              id="repo-url"
              type="url"
              placeholder="https://github.com/owner/repo"
              value={repoUrl}
              onChange={(e) => setRepoUrl(e.target.value)}
              required
              className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-500"
            />
            <p className="text-xs text-slate-500">
              Enter the full GitHub repository URL
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="policy" className="text-slate-300">Policy Preset</Label>
            <Select value={policyPreset} onValueChange={setPolicyPreset}>
              <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-slate-800 border-slate-700">
                <SelectItem value="solo">Solo Developer</SelectItem>
                <SelectItem value="small_team">Small Team (2-5)</SelectItem>
                <SelectItem value="strict_enterprise">Strict Enterprise</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-slate-500">
              Choose a policy configuration that matches your team size
            </p>
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              className="border-slate-700 text-slate-300"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={!repoUrl || addRepoMutation.isPending}
              className="bg-gradient-to-r from-blue-500 to-emerald-500"
            >
              {addRepoMutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Adding...
                </>
              ) : (
                "Add Repository"
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}