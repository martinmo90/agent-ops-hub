import React from "react";
import { Card } from "@/components/ui/card";
import { Sparkles } from "lucide-react";

export default function AgentCard({ type, name, role, description, icon, gradient }) {
  return (
    <Card className="group relative overflow-hidden bg-slate-900/50 border-slate-800 hover:border-slate-700 transition-all duration-500 hover:shadow-2xl">
      {/* Gradient overlay */}
      <div className={`absolute inset-0 bg-gradient-to-br ${gradient} opacity-0 group-hover:opacity-10 transition-opacity duration-500`}></div>
      
      <div className="relative p-6">
        {/* Header */}
        <div className="flex items-start gap-3 mb-4">
          <div className={`text-3xl bg-gradient-to-br ${gradient} p-3 rounded-2xl shadow-lg`}>
            {icon}
          </div>
          <div className="flex-1">
            <h3 className="text-lg font-bold text-white">{name}</h3>
            <p className="text-sm text-slate-400">{role}</p>
          </div>
          <Sparkles className={`w-4 h-4 bg-gradient-to-br ${gradient} bg-clip-text text-transparent opacity-60`} />
        </div>

        {/* Description */}
        <p className="text-slate-300 text-sm leading-relaxed">{description}</p>
      </div>
    </Card>
  );
}