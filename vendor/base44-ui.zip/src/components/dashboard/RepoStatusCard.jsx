import React from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, XCircle, Clock, ExternalLink, MessageSquare, Play } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format } from "date-fns";

const statusColors = {
  ready: "text-green-400 bg-green-500/10 border-green-500/30",
  needs_attention: "text-orange-400 bg-orange-500/10 border-orange-500/30",
  initializing: "text-blue-400 bg-blue-500/10 border-blue-500/30",
  error: "text-red-400 bg-red-500/10 border-red-500/30"
};

const statusIcons = {
  ready: CheckCircle2,
  needs_attention: Clock,
  initializing: Clock,
  error: XCircle
};

const checkLabels = {
  merge_queue_ci: "Merge Queue CI",
  baseline_guard: "Baseline Guard",
  pr_size_gate: "PR Size Gate",
  branch_protection: "Branch Protection",
  auto_merge: "Auto-merge",
  nightly_demo: "Nightly Demo"
};

export default function RepoStatusCard({ repo, operations }) {
  const navigate = useNavigate();
  const StatusIcon = statusIcons[repo.status];

  const completedChecks = Object.values(repo.checks || {}).filter(Boolean).length;
  const totalChecks = Object.keys(checkLabels).length;
  const readinessPercent = Math.round((completedChecks / totalChecks) * 100);

  const recentOperations = operations.slice(0, 3);

  return (
    <Card className="group relative overflow-hidden bg-slate-900/50 border-slate-800 hover:border-slate-700 transition-all">
      <div className="p-6">
        {/* Header */}
        <div className="flex items-start justify-between mb-6">
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <h3 className="text-xl font-bold text-white">{repo.repo_name}</h3>
              <a 
                href={repo.repo_url} 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-slate-400 hover:text-blue-400 transition-colors"
              >
                <ExternalLink className="w-4 h-4" />
              </a>
            </div>
            <div className="flex items-center gap-3">
              <Badge className={`${statusColors[repo.status]} border font-medium`}>
                <StatusIcon className="w-3 h-3 mr-1" />
                {repo.status.replace('_', ' ')}
              </Badge>
              <Badge variant="outline" className="text-slate-400 border-slate-700">
                {repo.policy_preset}
              </Badge>
            </div>
          </div>
          
          {/* Readiness Score */}
          <div className="text-center">
            <div className="relative w-20 h-20">
              <svg className="w-20 h-20 transform -rotate-90">
                <circle
                  cx="40"
                  cy="40"
                  r="32"
                  stroke="currentColor"
                  strokeWidth="6"
                  fill="transparent"
                  className="text-slate-800"
                />
                <circle
                  cx="40"
                  cy="40"
                  r="32"
                  stroke="currentColor"
                  strokeWidth="6"
                  fill="transparent"
                  strokeDasharray={`${readinessPercent * 2.01} 201`}
                  className={readinessPercent === 100 ? "text-green-500" : "text-blue-500"}
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-xl font-bold text-white">{readinessPercent}%</span>
              </div>
            </div>
            <p className="text-xs text-slate-500 mt-1">Ops Ready</p>
          </div>
        </div>

        {/* Checks Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-6">
          {Object.entries(checkLabels).map(([key, label]) => {
            const isComplete = repo.checks?.[key];
            return (
              <div 
                key={key}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg border ${
                  isComplete 
                    ? "bg-green-500/10 border-green-500/30" 
                    : "bg-slate-800/50 border-slate-700"
                }`}
              >
                {isComplete ? (
                  <CheckCircle2 className="w-4 h-4 text-green-400 flex-shrink-0" />
                ) : (
                  <XCircle className="w-4 h-4 text-slate-600 flex-shrink-0" />
                )}
                <span className={`text-xs ${isComplete ? "text-green-300" : "text-slate-400"}`}>
                  {label}
                </span>
              </div>
            );
          })}
        </div>

        {/* Recent Operations */}
        {recentOperations.length > 0 && (
          <div className="mb-6">
            <h4 className="text-sm font-semibold text-slate-400 mb-3">Recent Operations</h4>
            <div className="space-y-2">
              {recentOperations.map((op) => (
                <div key={op.id} className="flex items-center justify-between text-sm bg-slate-800/30 px-3 py-2 rounded-lg">
                  <span className="text-slate-300">{op.operation_type.replace(/_/g, ' ')}</span>
                  <Badge 
                    variant="outline" 
                    className={
                      op.status === 'completed' ? "border-green-500/30 text-green-400" :
                      op.status === 'failed' ? "border-red-500/30 text-red-400" :
                      op.status === 'in_progress' ? "border-blue-500/30 text-blue-400" :
                      "border-slate-700 text-slate-400"
                    }
                  >
                    {op.status}
                  </Badge>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Actions */}
        <div className="flex gap-3">
          <Button
            onClick={() => navigate(createPageUrl("RepoDetail") + `?id=${repo.id}`)}
            className="flex-1 bg-blue-500/20 hover:bg-blue-500/30 text-blue-400 border border-blue-500/30"
          >
            <Play className="w-4 h-4 mr-2" />
            Run Operations
          </Button>
          <Button
            onClick={() => navigate(createPageUrl("Chat") + `?repo=${repo.id}&agent=atlas`)}
            variant="outline"
            className="border-slate-700 text-slate-300 hover:bg-slate-800"
          >
            <MessageSquare className="w-4 h-4 mr-2" />
            Chat
          </Button>
        </div>

        {repo.last_scan && (
          <p className="text-xs text-slate-500 mt-3 text-center">
            Last scanned {format(new Date(repo.last_scan), "MMM d, h:mm a")}
          </p>
        )}
      </div>
    </Card>
  );
}