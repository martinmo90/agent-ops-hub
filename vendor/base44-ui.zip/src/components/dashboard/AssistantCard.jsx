import React from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MessageSquare, TrendingUp } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

const assistantStyles = {
  chatgpt: {
    gradient: "from-emerald-500 to-teal-500",
    glow: "group-hover:shadow-emerald-500/50",
    icon: "🎯"
  },
  copilot: {
    gradient: "from-blue-500 to-cyan-500",
    glow: "group-hover:shadow-blue-500/50",
    icon: "💻"
  },
  claude: {
    gradient: "from-orange-500 to-amber-500",
    glow: "group-hover:shadow-orange-500/50",
    icon: "🏗️"
  },
  cursor: {
    gradient: "from-purple-500 to-pink-500",
    glow: "group-hover:shadow-purple-500/50",
    icon: "🚀"
  }
};

export default function AssistantCard({ type, name, role, description, conversationCount }) {
  const navigate = useNavigate();
  const style = assistantStyles[type];

  const handleNewChat = () => {
    navigate(createPageUrl("Chat") + `?assistant=${type}`);
  };

  return (
    <Card className={`group relative overflow-hidden bg-slate-900/50 border-slate-800 hover:border-slate-700 transition-all duration-500 ${style.glow} hover:shadow-2xl cursor-pointer`}>
      {/* Gradient overlay */}
      <div className={`absolute inset-0 bg-gradient-to-br ${style.gradient} opacity-0 group-hover:opacity-10 transition-opacity duration-500`}></div>
      
      <div className="relative p-6">
        {/* Header */}
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className={`text-4xl bg-gradient-to-br ${style.gradient} p-3 rounded-2xl shadow-lg`}>
              {style.icon}
            </div>
            <div>
              <h3 className="text-xl font-bold text-white">{name}</h3>
              <p className="text-sm text-slate-400">{role}</p>
            </div>
          </div>
          <div className={`flex items-center gap-1 px-3 py-1 rounded-full bg-gradient-to-r ${style.gradient} bg-opacity-20`}>
            <MessageSquare className="w-3 h-3 text-white" />
            <span className="text-xs text-white font-medium">{conversationCount || 0}</span>
          </div>
        </div>

        {/* Description */}
        <p className="text-slate-300 text-sm mb-6 leading-relaxed">{description}</p>

        {/* Action */}
        <Button 
          onClick={handleNewChat}
          className={`w-full bg-gradient-to-r ${style.gradient} hover:opacity-90 text-white border-0 shadow-lg group-hover:shadow-xl transition-all duration-300`}
        >
          <MessageSquare className="w-4 h-4 mr-2" />
          Start New Chat
        </Button>

        {conversationCount > 0 && (
          <div className="mt-3 flex items-center justify-center gap-2 text-xs text-slate-500">
            <TrendingUp className="w-3 h-3" />
            <span>{conversationCount} conversation{conversationCount !== 1 ? 's' : ''} active</span>
          </div>
        )}
      </div>
    </Card>
  );
}