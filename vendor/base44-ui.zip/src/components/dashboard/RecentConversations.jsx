import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MessageSquare, Clock, ExternalLink } from "lucide-react";
import { format } from "date-fns";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

const assistantColors = {
  chatgpt: "text-emerald-400 bg-emerald-500/10",
  copilot: "text-blue-400 bg-blue-500/10",
  claude: "text-orange-400 bg-orange-500/10",
  cursor: "text-purple-400 bg-purple-500/10"
};

const assistantNames = {
  chatgpt: "ChatGPT PM",
  copilot: "Copilot Dev",
  claude: "Claude Architect",
  cursor: "Cursor Deploy"
};

export default function RecentConversations({ conversations }) {
  const navigate = useNavigate();

  if (!conversations || conversations.length === 0) {
    return (
      <Card className="bg-slate-900/50 border-slate-800">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Clock className="w-5 h-5" />
            Recent Conversations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-12">
            <MessageSquare className="w-12 h-12 text-slate-600 mx-auto mb-3" />
            <p className="text-slate-400">No conversations yet. Start chatting with your AI team!</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-slate-900/50 border-slate-800">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Clock className="w-5 h-5" />
          Recent Conversations
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {conversations.slice(0, 5).map((conv) => (
          <div 
            key={conv.id}
            onClick={() => navigate(createPageUrl("Chat") + `?id=${conv.id}`)}
            className="group p-4 rounded-lg bg-slate-800/50 hover:bg-slate-800 border border-slate-700 hover:border-slate-600 transition-all cursor-pointer"
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-2">
                  <span className={`text-xs font-medium px-2 py-1 rounded ${assistantColors[conv.assistant_type]}`}>
                    {assistantNames[conv.assistant_type]}
                  </span>
                  {conv.last_message_at && (
                    <span className="text-xs text-slate-500">
                      {format(new Date(conv.last_message_at), "MMM d, h:mm a")}
                    </span>
                  )}
                </div>
                <h4 className="text-white font-medium truncate group-hover:text-indigo-400 transition-colors">
                  {conv.title}
                </h4>
                {conv.messages && conv.messages.length > 0 && (
                  <p className="text-sm text-slate-400 truncate mt-1">
                    {conv.messages[conv.messages.length - 1].content}
                  </p>
                )}
              </div>
              <ExternalLink className="w-4 h-4 text-slate-600 group-hover:text-indigo-400 transition-colors flex-shrink-0" />
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}