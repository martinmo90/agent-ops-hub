import React from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { GitPullRequest, Clock, Zap, Loader2 } from "lucide-react";
import { toast } from "sonner";

const difficultyColors = {
  easy: "bg-green-500/20 text-green-400 border-green-500/30",
  medium: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
  comprehensive: "bg-purple-500/20 text-purple-400 border-purple-500/30"
};

const agentIcons = {
  atlas: "🗺️",
  ci_cd: "⚙️",
  security: "🔒",
  code_review: "📝",
  vendor: "📦"
};

export default function PRPackCard({ pack, repoId }) {
  const queryClient = useQueryClient();

  const executeMutation = useMutation({
    mutationFn: async () => {
      // Simulate operation creation
      const operation = await base44.entities.Operation.create({
        repo_id: repoId,
        operation_type: pack.id,
        status: "pending",
        agent_used: pack.agent,
        details: `Executing PR Pack: ${pack.name}`
      });

      // Simulate AI execution (in real app, this would trigger actual GitHub operations)
      await new Promise(resolve => setTimeout(resolve, 2000));

      // Update operation status
      await base44.entities.Operation.update(operation.id, {
        status: "completed",
        pr_url: `https://github.com/example/repo/pull/${Math.floor(Math.random() * 1000)}`,
        pr_number: Math.floor(Math.random() * 1000),
        completed_at: new Date().toISOString(),
        details: `Successfully created PR for: ${pack.name}`
      });

      return operation;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['operations'] });
      toast.success(`${pack.name} - PR opened successfully!`);
    },
    onError: () => {
      toast.error("Failed to execute PR Pack");
    }
  });

  return (
    <Card className="group relative overflow-hidden bg-slate-900/50 border-slate-800 hover:border-slate-700 transition-all hover:shadow-xl">
      <div className="p-6">
        {/* Header */}
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-2">
            <span className="text-2xl">{agentIcons[pack.agent]}</span>
            <div className="flex flex-col">
              <h3 className="text-lg font-bold text-white">{pack.name}</h3>
            </div>
          </div>
          <Badge className={`${difficultyColors[pack.difficulty]} border`}>
            {pack.difficulty}
          </Badge>
        </div>

        {/* Description */}
        <p className="text-slate-300 text-sm leading-relaxed mb-4">
          {pack.description}
        </p>

        {/* Checks */}
        {pack.checks.length > 0 && (
          <div className="mb-4">
            <p className="text-xs text-slate-500 mb-2">Adds checks:</p>
            <div className="space-y-1">
              {pack.checks.map((check, idx) => (
                <div key={idx} className="text-xs text-slate-400 bg-slate-800/50 px-2 py-1 rounded">
                  ✓ {check}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Meta */}
        <div className="flex items-center gap-3 mb-4 text-xs text-slate-500">
          <div className="flex items-center gap-1">
            <Clock className="w-3 h-3" />
            {pack.time}
          </div>
          <div className="flex items-center gap-1">
            <Zap className="w-3 h-3" />
            {pack.agent}
          </div>
        </div>

        {/* Action */}
        <Button
          onClick={() => executeMutation.mutate()}
          disabled={executeMutation.isPending}
          className="w-full bg-blue-500/20 hover:bg-blue-500/30 text-blue-400 border border-blue-500/30"
        >
          {executeMutation.isPending ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Creating PR...
            </>
          ) : (
            <>
              <GitPullRequest className="w-4 h-4 mr-2" />
              Open PR
            </>
          )}
        </Button>
      </div>
    </Card>
  );
}